#ifndef CHANNEL_H
#define CHANNEL_H

#include "Epoll.h"

class Epoll; //解决循环引用问题

class Channel
{
public:
    Channel(Epoll *_ep, int _fd);
    void enable_reading();

    int get_fd() const;
    uint32_t get_events() const;
    uint32_t get_revents() const;
    bool is_in_epoll() const;

    void set_revents(uint32_t _ev);
    void set_in_epoll(bool _in_epoll);
private:
    Epoll *ep_;
    int fd_;
    uint32_t events_;
    uint32_t revents_;
    bool in_epoll_;
};

#endif