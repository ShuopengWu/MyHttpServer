#ifndef ACCEPTOR_H
#define ACCEPTOR_H

#include "EventLoop.h"
#include "Socket.h"
#include "InetAddress.h"
#include "Channel.h"

class Acceptor
{
public:
    Acceptor(std::shared_ptr<EventLoop> _loop);
    ~Acceptor();
    void accept_connection();
    void set_new_connection_callback(const std::function<void(std::shared_ptr<Socket>)> &_function);
private:
    std::shared_ptr<EventLoop> loop_;
    std::shared_ptr<Socket> socket_;
    InetAddress addr_;
    std::unique_ptr<Channel> channel_;
    std::function<void(std::shared_ptr<Socket>)> new_connection_callback_;
};

#endif