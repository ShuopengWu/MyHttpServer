#include "EventLoop.h"

EventLoop::EventLoop() : epoll_(std::make_unique<Epoll>()) , quit_(false)
{
}

EventLoop::~EventLoop()
{
}

void EventLoop::loop()
{
    while (!quit_)
    {
        std::vector<Channel *> channels = epoll_->poll();

        for (auto it = channels.begin(); it != channels.end(); it++)
            (*it)->handle_callback();
    }
    
}

void EventLoop::update_channel(Channel *_channel)
{
    epoll_->update_channel(_channel);
}

void EventLoop::delete_event(int fd)
{
    epoll_->delete_event(fd);
}
