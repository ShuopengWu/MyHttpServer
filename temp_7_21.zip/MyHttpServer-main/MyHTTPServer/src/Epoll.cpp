#include "Epoll.h"
#include "util.h"

Epoll::Epoll()
{
    epoll_fd_ = epoll_create1(0);
    error_if(epoll_fd_ == -1, "epoll create error");
    events = new epoll_event[MAX_EPOLL_EVENTS];
    memset(events, 0, sizeof(epoll_event) * MAX_EPOLL_EVENTS); //不要使用events(指针)的size
}

Epoll::~Epoll()
{
    if (epoll_fd_ != -1)
        close(epoll_fd_);
    delete []events;
}

void Epoll::delete_event(int fd)
{
    error_if(epoll_ctl(epoll_fd_, EPOLL_CTL_DEL, fd, NULL) == -1, "delete event to epoll failed");
}

std::vector<Channel *> Epoll::poll(int timeout)
{
    int nfds = epoll_wait(epoll_fd_, events, MAX_EPOLL_EVENTS, timeout);
    error_if(nfds == -1, "epoll waiting error");
    
    std::vector<Channel *> active_channels;
    for (int i = 0; i < nfds; i++) {
        active_channels.push_back(static_cast<Channel*>(events[i].data.ptr)); // 显示转换
        active_channels[i]->set_revents(events[i].events);
    }

    return std::move(active_channels);
}

void Epoll::update_channel(Channel *channel)
{
    int fd = channel->get_fd();　//不要在向ev.data设置fd,ev.data是union,只能同时存在一种类型
    epoll_event ev;
    ev.data.ptr = channel;
    ev.events = channel->get_events();
    error_if(epoll_ctl(epoll_fd_, (channel->is_in_epoll() ? EPOLL_CTL_MOD : EPOLL_CTL_ADD), fd, &ev) == -1, "epoll ctl " + std::string(channel->is_in_epoll() ? "mod" : "add") + " failed");
    channel->set_in_epoll(true);
}
