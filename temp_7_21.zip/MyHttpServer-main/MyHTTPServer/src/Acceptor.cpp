#include "Acceptor.h"

Acceptor::Acceptor(std::shared_ptr<EventLoop> _loop) : loop_(_loop)
{
    socket_ = std::make_shared<Socket>();
    addr_ = InetAddress("0.0.0.0", 8080);
    socket_->bind_socket(addr_);
    socket_->listen_socket();
    socket_->set_socket_non_blocking();

    channel_ = std::make_unique<Channel>(loop_.get(), socket_->get_socket_fd());
    auto callback_function = std::bind(accept_connection, this);
    channel_->set_callback(callback_function);
    channel_->enable_reading();
}

Acceptor::~Acceptor()
{
}

void Acceptor::accept_connection()
{
    new_connection_callback_(socket_);
}

void Acceptor::set_new_connection_callback(const std::function<void(std::shared_ptr<Socket>)> &_function)
{
    new_connection_callback_ = _function;
}
