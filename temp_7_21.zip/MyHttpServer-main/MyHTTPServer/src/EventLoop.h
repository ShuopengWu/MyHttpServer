#ifndef EVENTLOOP_H
#define EVENTLOOP_H

#include "Epoll.h"
#include <memory>

class Epoll;

class EventLoop
{
public:
    EventLoop();
    ~EventLoop();
    void loop();
    void update_channel(Channel *_channel);
    void delete_event(int fd);
private:
    std::unique_ptr<Epoll> epoll_;
    bool quit_;
};

#endif