#ifndef SERVER_H
#define SERVER_H

#include "EventLoop.h"
#include "Socket.h"
#include "Acceptor.h"

class EventLoop;
class Socket;

class Server
{
public:
    Server(EventLoop *_loop);
    ~Server();
    void handle_read_event(int _client_socket_fd);
    void new_connection(std::shared_ptr<Socket> _socket);
private:
    EventLoop *loop_;
    std::unique_ptr<Acceptor> acceptor_;
};

#endif