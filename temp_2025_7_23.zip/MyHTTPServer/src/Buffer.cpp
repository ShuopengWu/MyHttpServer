#include "Buffer.h"

Buffer::Buffer() : buffer_("")
{
}

void Buffer::append(const char *_str, int size)
{
    if (size <= 0)
        return;
    
    buffer_.append(_str, size);
}

ssize_t Buffer::size()
{
    return buffer_.size();
}

const char *Buffer::c_str()
{
    return buffer_.c_str();
}

void Buffer::clear()
{
    buffer_.clear();
}
