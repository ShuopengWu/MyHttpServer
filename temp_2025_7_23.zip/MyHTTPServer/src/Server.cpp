#include "Server.h"
#include "Channel.h"
#include "util.h"
#include "Epoll.h"

Server::Server(std::shared_ptr<EventLoop> _loop) : loop_(_loop), acceptor_(std::make_unique<Acceptor>())
{
	auto callback = std::bind(&Server::new_connection, this, std::placeholders::_1);
	acceptor_->set_new_connection_callback(callback);
}

void Server::new_connection(std::shared_ptr<Socket> server_socket)
{
	std::shared_ptr<Connection> connection = std::make_shared<Connection>(loop_, server_socket);
	auto callback = std::bind(&Server::delete_connection, this, std::placeholders::_1);
	connection->set_delete_connection_callback(callback);
	connections_[server_socket->get_socket_fd()] = connection;
}

void Server::delete_connection(std::shared_ptr<Socket> server_socket)
{
	connections_.erase(server_socket->get_socket_fd());
}
