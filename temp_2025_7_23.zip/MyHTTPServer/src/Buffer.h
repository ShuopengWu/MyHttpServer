#ifndef BUFFER_H
#define BUFFER_H

#include <string>

class Buffer
{
public:
    Buffer();
    void append(const char *_str, int size);
    ssize_t size();
    const char *c_str();
    void clear();
    
private:
    std::string buffer_;
};

#endif