#ifndef CONNECTION_H
#define CONNECTION_H

#include <functional>

#include "EventLoop.h"
#include "Socket.h"
#include "Channel.h"
#include "Buffer.h"

class Connection
{
    static constexpr int MAX_READ_BUFFER_SZIE = 0x0400;
public:
    Connection(std::shared_ptr<EventLoop> loop_, std::shared_ptr<Socket> client_socket_);
    void set_delete_connection_callback(std::function<std::shared_ptr<Socket>> callback_);
    void echo(int client_socket_fd);
private:
    std::shared_ptr<EventLoop> _loop;
    std::shared_ptr<Socket> _client_socket;
    std::shared_ptr<Channel> _client_channel;
    std::function<std::shared_ptr<Socket>> _delete_connection_callback;
    Buffer _read_buffer;
};

#endif