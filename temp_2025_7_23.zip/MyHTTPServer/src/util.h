#ifndef UTIL_H
#define UTIL_H

#include <string>
#include <cstdlib>

void error_if(bool condition, std::string error_message);

#endif
