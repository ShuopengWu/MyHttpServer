#include"Acceptor.h"

Acceptor::Acceptor(std::shared_ptr<EventLoop> loop_) : _loop(loop_)
{
    _server_socket = std::make_shared<Socket>();
    _server_addr = InetAddress(8080);
    _server_socket->bind_socket(_server_addr);
    _server_socket->listen_socket();
    _server_socket->set_socket_non_blocking();

    _server_channel = std::make_shared<Channel>(loop_.get(), _server_socket->get_socket_fd());
    _server_channel->enable_reading();
    auto callback = std::bind(&Acceptor::accept_new_connection, this);
    _server_channel->set_callback(callback);
}

void Acceptor::accept_new_connection()
{
    _new_connection_callback(_server_socket);
}

void Acceptor::set_new_connection_callback(std::function<std::shared_ptr<Socket>> callback_)
{
    _new_connection_callback = callback_;
}
