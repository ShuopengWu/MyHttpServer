#ifndef ACCEPTOR_H
#define ACCEPTOR_H

#include "EventLoop.h"
#include "Socket.h"
#include "Channel.h"
#include "InetAddress.h"

class Acceptor
{
public:
    Acceptor(std::shared_ptr<EventLoop> loop_);
    void accept_new_connection();
    void set_new_connection_callback(std::function<std::shared_ptr<Socket>> callback_);
private:
    std::shared_ptr<Socket> _server_socket;
    InetAddress _server_addr;
    std::shared_ptr<Channel> _server_channel;
    std::shared_ptr<EventLoop> _loop;
    std::function<std::shared_ptr<Socket>> _new_connection_callback;
};

#endif