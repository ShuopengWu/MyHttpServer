#include "Connection.h"

Connection::Connection(std::shared_ptr<EventLoop> loop_, std::shared_ptr<Socket> client_socket_) : _loop(loop_), _client_socket(client_socket_)
{
    _client_channel = std::make_shared<Channel>(_loop, _client_socket->get_socket_fd());
    _client_channel->enable_reading();
    auto callback = std::bind(&Connection::echo, this, _client_socket->get_socket_fd());
    _client_channel->set_callback(callback);
}

void Connection::set_delete_connection_callback(std::function<std::shared_ptr<Socket>> callback_)
{
    _delete_connection_callback = callback_;
}

void Connection::echo(int client_socket_fd)
{
    _read_buffer.clear();
	char buffer[MAX_READ_BUFFER_SZIE];
	while (true) {
		memset(buffer, 0, MAX_READ_BUFFER_SZIE);
		auto read_size = recv(client_fd, buffer, sizeof(buffer), 0);

		if (read_size > 0) {
			std::cout << "receive client " << client_fd << " (" << read_size << " bytes):" << std::endl;
			std::cout.write(buffer, read_size);
			std::cout << std::endl;
            _read_buffer->append(buffer. read_size);
		}
		else if (read_size == -1) {
			if (errno == EINTR) {
				std::cout << "Client W, continue to read" << std::endl;
				continue;
			}
			else if (errno == EAGAIN || errno == EWOULDBLOCK) {
				std::cout << "finish reading!" << std::endl;
                send(client_fd, _read_buffer.c_str(), _read_buffer.size(), 0);
				break;
			}
		}
		else if (read_size == 0) {
			std::cout << "client " << client_fd << " disconnection!" << std::endl;
			close(client_fd);
            _delete_connection_callback(_client_socket);
			break;
		}
	}
}
