#ifndef SERVER_H
#define SERVER_H

#include <map>

#include "EventLoop.h"
#include "Socket.h"
#include "Acceptor.h"
#include "Connection.h"

class Server
{
public:
	Server(std::shared_ptr<EventLoop> _loop);

	void new_connection(std::shared_ptr<Socket> server_socket);
	void delete_connection(std::shared_ptr<Socket> server_socket);
private:
	std::shared_ptr<EventLoop> loop_;
	std::unique_ptr<Acceptor> acceptor_;
	std::map<int, std::shared_ptr<Connection>> connections_;
};

#endif // !SERVER_H
