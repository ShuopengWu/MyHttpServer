#ifndef CHANNEL_H
#define CHANNEL_H

#include "Epoll.h"
#include <functional>

class Epoll; //解决循环引用问题
class EventLoop;

class Channel
{
public:
    Channel(EventLoop *_ep, int _fd);
    void enable_reading();
    int get_fd() const;
    uint32_t get_events() const;
    uint32_t get_revents() const;
    bool is_in_epoll() const;
    void set_revents(uint32_t _ev);
    void set_in_epoll(bool _in_epoll);
    void set_callback(std::function<void()> _callback);
    void handle_callback();
private:
    Epoll *ep_;
    int fd_;
    uint32_t events_;
    uint32_t revents_;
    bool in_epoll_;
    std::function<void()> callback_;
};

#endif