#include "Server.h"

Server::Server(EventLoop *_loop) : loop_(_loop)
{
    Socket *server_socket = new Socket();
    InetAddress server_addr();
    server_socket->bind_socket(server_addr);
    server_socket->listen_socket();
    server_socket->set_socket_non_blocking();

    Channel server_channer(_loop, server_socket->get_socket_fd());
    server_channer.enable_reading();

    auto callback_function = std::bind(&new_connection, this, server_socket);
    server_channer->set_callback(callback_function);
}

Server::~Server()
{
}

void Server::handle_read_event(int _client_socket_fd)
{
    static constexpr int MAX_READ_BUFFER_SZIE = 0x0400;
    char buffer[MAX_READ_BUFFER_SZIE];
    while (true)
    {
        memset(buffer, 0, MAX_READ_BUFFER_SZIE);
        auto read_size = recv(client_socket_fd, buffer, sizeof(buffer), 0);

        if (read_size > 0)
        {
            std::cout << "receive client " << client_socket_fd << " (" << read_size << " bytes):" << std::endl;
            std::cout.write(buffer, read_size);
            std::cout << std::endl;
            // TBD:回显,后续实现完整发送逻辑
            send(client_socket_fd, buffer, read_size, 0);
        }
        else if (read_size == -1)
        {
            if (errno == EINTR)
            { // 客户端中断
                std::cout << "Client interrupted, continue to read" << std::endl;
                continue;
            }
            else if (errno == EAGAIN || errno == EWOULDBLOCK)
            { // 读取完毕
                std::cout << "finish reading!" << std::endl;
                break;
            }
        }
        else if (read_size == 0)
        { // 客户端退出
            std::cout << "client " << client_socket_fd << " disconnection!" << std::endl;
            loop_->delete_event(client_socket_fd);
            close(client_socket_fd);
            break;
        }
    }
}

void Server::new_connection(Socket *_socket)
{
    InetAddress client_address;
    int client_socket_fd = server_socket->accept_client_socket(client_address);
    
    if (client_socket_fd == -1)
    {
        if (errno == EAGAIN || errno == EWOULDBLOCK)
            break;
        else
        {
            std::cerr << "accept error occur, statu is " << errno << std::endl;
            break;
        }
    }

    // TBD : Socket::set_socket_non_blocking static化?
    error_if(fcntl(client_socket_fd, F_SETFL, fcntl(client_socket_fd, F_GETFL) | O_NONBLOCK) == -1, "failed to set socket to non-blocking state");
    Channel *clnt_channel = new Channel(epoll.get(), client_socket_fd);
    clnt_channel->enable_reading();

    auto callback_function = std::bind(handle_read_event, this, client_socket_fd);
    clnt_channel->set_callback(callback_function);
}
